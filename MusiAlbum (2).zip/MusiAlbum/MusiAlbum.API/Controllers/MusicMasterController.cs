﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusiAlbum.API.Business.Abstract;

namespace MusiAlbum.API.Controllers
{ 
    [Route("api/[controller]")]
    [ApiController]
    public class MusicMasterController : ControllerBase
    {
        private readonly IMusicMasterContext _musicMasterContext;
        public MusicMasterController(IMusicMasterContext musicMasterContext)
        {
            _musicMasterContext = musicMasterContext;
        } 
        [HttpGet("GetAllMusicMaster")]
        public async Task<IActionResult> GetAllMusicMaster()
        {
            var res = await _musicMasterContext.GetAllMusic();
            var resp = Ok(new { status = 200, success = true, data = res });
            return resp;
        }
    }
}
