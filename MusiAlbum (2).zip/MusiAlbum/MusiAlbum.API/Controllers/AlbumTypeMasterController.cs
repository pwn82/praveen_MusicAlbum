﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusiAlbum.API.Business.Abstract;
using MusiAlbum.Data.Models;

namespace MusiAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumTypeMasterController : ControllerBase
    {
        private readonly IAlbumTypeMasterContext _albumTypeMasterContext;
        public AlbumTypeMasterController(IAlbumTypeMasterContext albumTypeMasterContext)
        {
            _albumTypeMasterContext = albumTypeMasterContext;
        }
        [HttpPost("SaveAlbum")]
        public async Task<IActionResult> SaveAlbum(AlbumTypeMaster albumTypeMaster)
        {
            var res = await _albumTypeMasterContext.SaveAlbumTypeMaster(albumTypeMaster);
            var response = Ok(new { status = 200, success = true, data = "Data Successfully Inserted" });
            return response;
        }
        [HttpPost("DeleteAlbum")]
        public async Task<IActionResult> DeleteAlbum(AlbumTypeMaster albumTypeMaster)
        {
            var res = await _albumTypeMasterContext.DeleteAlbumTypeMaster(albumTypeMaster);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpPost("ModifyAlbum")]
        public async Task<IActionResult>ModifyAlbum(AlbumTypeMaster albumTypeMaster)
        {
            var res = await _albumTypeMasterContext.ModifyAlbumTypeMaster(albumTypeMaster);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpGet("GetbyAlbumName")]
        public async Task<IActionResult> GetbyAlbumName(int Album_id)
        {
            var res = await _albumTypeMasterContext.GetAlbumTypeMaster(Album_id);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpGet("GetAllAlbum")]
        public async Task<IActionResult> GetAllAlbum()
        {
            var res = await _albumTypeMasterContext.GetAllAlbumTypeMaster();
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
    }
}
