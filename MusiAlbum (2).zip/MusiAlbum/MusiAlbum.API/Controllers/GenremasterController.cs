﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusiAlbum.API.Business.Abstract;
using MusiAlbum.Data.Models;

namespace MusiAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenremasterController : ControllerBase
    {
        private readonly IGenremasterContext _genremasterContext;
        public GenremasterController(IGenremasterContext genremasterContext)
        {
            _genremasterContext = genremasterContext;
        }
        [HttpPost("SaveGenreMaster")]
        public async Task<IActionResult> SaveGenreMaster(GenreMaster genreMaster)
        {
            var res = await _genremasterContext.SaveGenremaster(genreMaster);
            var response = Ok(new { status = 200, success = true, data = "Data Successfully Inserted" });
            return response;
        }
        [HttpPost("DeleteGenreMaster")]
        public async Task<IActionResult> DeleteGenreMaster(GenreMaster genreMaster)
        {
            var res = await _genremasterContext.DeleteGenremaster(genreMaster);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpPost("ModifyGenreMaster")]
        public async Task<IActionResult> ModifyGenreMaster(GenreMaster genreMaster)
        {
            var res = await _genremasterContext.ModifyGenremaster(genreMaster);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpGet("GetbyGenremasterId")]
        public async Task<IActionResult> GetbyGenremasterId(int genre_id)
        {
            var res = await _genremasterContext.GetGenremaster(genre_id);
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
        [HttpGet("GetAllGenremaster")]
        public async Task<IActionResult> GetAllGenremaster()
        {
            var res = await _genremasterContext.GetAllGenremaster();
            var response = Ok(new { status = 200, success = true, data = res });
            return response;
        }
    }
}
