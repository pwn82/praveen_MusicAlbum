﻿using MusiAlbum.API.Business.Abstract;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MusiAlbum.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Derived
{
    public class MusicMasterContext: IMusicMasterContext
    {
        private readonly IMusicMasterService _musicMasterService;
        public MusicMasterContext(IMusicMasterService musicMasterService)
        {
            _musicMasterService = musicMasterService;
        }
       public async Task<List<MusicMasterViewModel>> GetAllMusic()
        {
            var result = await _musicMasterService.GetAllMusic();
            return result;
        }

       
    }
}
