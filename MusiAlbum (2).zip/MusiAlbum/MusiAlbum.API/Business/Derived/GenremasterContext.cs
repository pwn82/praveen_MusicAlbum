﻿using MusiAlbum.API.Business.Abstract;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Derived
{
    public class GenremasterContext : IGenremasterContext
    {
        private readonly IGenremasterService _genremasterService;
        public GenremasterContext(IGenremasterService genremasterService)
        {
            _genremasterService = genremasterService;
        }
        public async Task<int> DeleteGenremaster(GenreMaster genreMaster)
        {
            var result =await _genremasterService.DeleteGenremaster(genreMaster);
            return result;
        }

        public async Task<List<GenreMaster>> GetAllGenremaster()
        {
            var result =await _genremasterService.GetAllGenremaster();
            return result;
        }

        public async Task<GenreMaster> GetGenremaster(int genre_id)
        {
            var result =await _genremasterService.GetGenremaster(genre_id);
            return result;
        }

        public async Task<int> ModifyGenremaster(GenreMaster genreMaster)
        {
            var result =await _genremasterService.ModifyGenremaster(genreMaster);
            return result;
        }

        public async Task<int> SaveGenremaster(GenreMaster genreMaster)
        {
            var result =await _genremasterService.SaveGenremaster(genreMaster);
            return result;
        }
    }
}
