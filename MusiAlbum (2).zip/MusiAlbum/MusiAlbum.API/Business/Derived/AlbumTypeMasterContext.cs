﻿using Microsoft.Extensions.Configuration;
using MusiAlbum.API.Business.Abstract;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Derived
{
    public class AlbumTypeMasterContext : IAlbumTypeMasterContext
    {
        private readonly IAlbumTypeMasterService _albumTypeMasterService;
        public AlbumTypeMasterContext(IAlbumTypeMasterService albumTypeMasterService)
        {
            _albumTypeMasterService = albumTypeMasterService;
        }

        public async Task<int> DeleteAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            var result = await _albumTypeMasterService.DeleteAlbumTypeMaster(albumTypeMaster);
            return result;
        }

        public async Task<AlbumTypeMaster> GetAlbumTypeMaster(int Album_id)
        {
            var result = await _albumTypeMasterService.GetAlbumTypeMaster(Album_id);
            return result;
        }

        public async Task<List<AlbumTypeMaster>> GetAllAlbumTypeMaster()
        {
            var result = await _albumTypeMasterService.GetAllAlbumTypeMaster();
            return result;
        }

        public async Task<int> ModifyAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            var result = await _albumTypeMasterService.ModifyAlbumTypeMaster(albumTypeMaster);
            return result;
        }

        public async Task<int> SaveAlbumTypeMaster(AlbumTypeMaster albumTypeMaster)
        {
            var result = await _albumTypeMasterService.SaveAlbumTypeMaster(albumTypeMaster);
            return result;
        }
    }
}
