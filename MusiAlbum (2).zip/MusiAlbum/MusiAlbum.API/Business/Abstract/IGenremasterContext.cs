﻿using MusiAlbum.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Abstract
{
    public interface IGenremasterContext
    {
        Task<int> SaveGenremaster(GenreMaster genreMaster);
        Task<int> DeleteGenremaster(GenreMaster genreMaster);
        Task<int> ModifyGenremaster(GenreMaster genreMaster);
        Task<List<GenreMaster>> GetAllGenremaster();
        Task<GenreMaster> GetGenremaster(int genre_id);
    }
}
