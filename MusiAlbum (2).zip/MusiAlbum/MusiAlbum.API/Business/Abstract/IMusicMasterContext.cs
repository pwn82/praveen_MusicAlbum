﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusiAlbum.API.Business.Abstract
{
    public interface IMusicMasterContext
    {
        Task<List<MusicMasterViewModel>> GetAllMusic();
    }
}
