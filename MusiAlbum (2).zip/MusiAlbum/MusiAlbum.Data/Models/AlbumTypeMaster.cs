﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.Models
{
    public class AlbumTypeMaster
    {
        public int Album_id { get; set; }
        public string album_name { get; set; }
        public int year { get; set; }
    }
}
