﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.Models
{
    public class MusicMaster
    {
        public int music_id { get; set; }
        public int album_id { get; set; }
        public int title_id { get; set; }
        public int artist_id { get; set; }
        public int genre_id { get; set; }
        public AlbumTypeMaster albumTypeMaster { get; set; }
        public ArtistMaster artistMaster { get; set; }
        public GenreMaster genreMaster { get; set; }
        public TitleMaster titleMaster { get; set; }
    }
}
