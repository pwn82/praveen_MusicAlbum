﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.Models
{
    public class GenreMaster
    {
        public int genre_id { get; set; }
        public string genere_name { get; set; }
    }
}
