﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
    public interface IMusicMasterService
    {
        Task<List<MusicMasterViewModel>> GetAllMusic();
    }
}
