﻿using MusiAlbum.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
    public interface IGenremasterService
    {
        Task<int> SaveGenremaster(GenreMaster genreMaster);
        Task<int> DeleteGenremaster(GenreMaster genreMaster);
        Task<int> ModifyGenremaster(GenreMaster genreMaster);
        Task<List<GenreMaster>> GetAllGenremaster();
        Task<GenreMaster> GetGenremaster(int genre_id);
    }
}
