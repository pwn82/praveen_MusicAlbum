﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
   public interface IMySqlConnectionService
    {
        MySqlParameter GetParameter(string parameter, object value);
        MySqlParameter GetParameterOut(string parameter, SqlDbType type, object value = null, ParameterDirection parameterDirection = ParameterDirection.InputOutput);
        Task<int> ExecuteNonQuery(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure);
        Task<object> ExecuteScalar(string procedureName, List<MySqlParameter> parameters);
        Task<MySqlDataReader> GetDataReader(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure);
        Task<DataSet> GetDataSteAsync(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure);
    }
}
