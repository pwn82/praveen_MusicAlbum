﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MusiAlbum.Data.ViewModels;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class MusicMasterService : IMusicMasterService
    {
        private readonly IMySqlConnectionService _mySqlConnectionService;
        public MusicMasterService(IMySqlConnectionService mySqlConnectionService)
        {
            _mySqlConnectionService = mySqlConnectionService;
        }
        public async Task<List<MusicMasterViewModel>> GetAllMusic()
        {
            List<MusicMasterViewModel> musicMasters = new List<MusicMasterViewModel>();
            //MusicMasterViewModel musicMaster = null;
            try
            {
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("GetAllMusic", null).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    //musicMaster = new MusicMasterViewModel
                    //{
                    MusicMasterViewModel musicMaster = new MusicMasterViewModel();
                      //music_id = Convert.ToInt32(mySqlDataReader["music_id"]),
                    musicMaster.album_id = Convert.ToInt32(mySqlDataReader["album_id"]);
                    musicMaster.album_name = Convert.ToString(mySqlDataReader["album_name"]);
                    musicMaster.year = Convert.ToInt32(mySqlDataReader["year"]);
                    musicMaster.title_id = Convert.ToInt32(mySqlDataReader["title_id"]);
                    musicMaster.title_name = Convert.ToString(mySqlDataReader["title_name"]);
                    musicMaster.artist_id = Convert.ToInt32(mySqlDataReader["artist_id"]);
                    musicMaster.artist_name = Convert.ToString(mySqlDataReader["artist_name"]);
                    musicMaster.profession = Convert.ToString(mySqlDataReader["profession"]);
                    musicMaster.genre_id = Convert.ToInt32(mySqlDataReader["genre_id"]);
                    musicMaster.genere_name = Convert.ToString(mySqlDataReader["genere_name"]);

                    //};
              musicMasters.Add(musicMaster);
                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return musicMasters ;
        }
    }
}
