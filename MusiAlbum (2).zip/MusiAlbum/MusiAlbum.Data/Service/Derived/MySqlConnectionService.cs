﻿using Microsoft.Extensions.Configuration;
using MusiAlbum.Data.Service.Abstract;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class MySqlConnectionService:IMySqlConnectionService
    {
        private string ConnectionString { get; set; }
        private readonly IConfiguration _configuration;
        public MySqlConnectionService(IConfiguration configuration)
        {
            this._configuration = configuration;
            this.ConnectionString = _configuration["ConnectionStrings:AlbumDataConnection"];
        }
        private MySqlConnection GetConnection()
        {
            MySqlConnection connection = new MySqlConnection(this.ConnectionString);
            if (connection.State != ConnectionState.Open)
                connection.Open();
            return connection;
        }
        private MySqlCommand GetCommand(MySqlConnection connection, string commandText, CommandType commandType)
        {
            MySqlCommand command = new MySqlCommand(commandText, connection as MySqlConnection);
            command.CommandType = commandType;
            //command.CommandTimeout = 50;
            return command;
        }
        public MySqlParameter GetParameter(string parameter, object value)
        {
            MySqlParameter parameterObject = new MySqlParameter(parameter, value != null ? value : DBNull.Value);
            parameterObject.Direction = ParameterDirection.Input;
            return parameterObject;
        }
        public MySqlParameter GetParameterOut(string parameter, SqlDbType type, object value = null, ParameterDirection parameterDirection = ParameterDirection.InputOutput)
        {
            MySqlParameter parameterObject = new MySqlParameter(parameter, type); ;
            if (type == SqlDbType.NVarChar || type == SqlDbType.VarChar || type == SqlDbType.NText || type == SqlDbType.Text)
            {
                parameterObject.Size = -1;
            }
            parameterObject.Direction = parameterDirection;
            if (value != null)
            {
                parameterObject.Value = value;
            }
            else
            {
                parameterObject.Value = DBNull.Value;
            }
            return parameterObject;
        }
        public async Task<int> ExecuteNonQuery(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            int returnValue = -1;
            try
            {
                using (MySqlConnection connection = this.GetConnection())
                {
                    MySqlCommand cmd = this.GetCommand(connection, procedureName, commandType);
                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }
                    returnValue = await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return returnValue;
        }
        public async Task<object> ExecuteScalar(string procedureName, List<MySqlParameter> parameters)
        {
            object returnValue = null;
            try
            {
                using (MySqlConnection connection = this.GetConnection())
                {
                    MySqlCommand cmd = this.GetCommand(connection, procedureName, CommandType.StoredProcedure);
                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }
                    returnValue = await cmd.ExecuteScalarAsync().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return returnValue;
        }
        public async Task<MySqlDataReader> GetDataReader(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            MySqlDataReader mySqlDataReader;
            try
            {
                MySqlConnection connection = this.GetConnection();
                {
                    MySqlCommand cmd = this.GetCommand(connection, procedureName, commandType);
                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }
                    mySqlDataReader = (MySqlDataReader)await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return mySqlDataReader;
        }
        public async Task<DataSet> GetDataSteAsync(string procedureName, List<MySqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            DataSet dataSet = new DataSet();
            try
            {
                using (MySqlConnection connection = this.GetConnection())
                {
                    MySqlCommand cmd = this.GetCommand(connection, procedureName, commandType);
                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }
                    MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(cmd);
                    await mySqlDataAdapter.FillAsync(dataSet);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return dataSet;
        }
    }
}

