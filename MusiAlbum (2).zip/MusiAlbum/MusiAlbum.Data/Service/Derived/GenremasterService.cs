﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class GenremasterService : IGenremasterService
    {
        private readonly IMySqlConnectionService _mySqlConnectionService;
        public GenremasterService(IMySqlConnectionService mySqlConnectionService)
        {
            _mySqlConnectionService = mySqlConnectionService;
        }
        public async Task<int> DeleteGenremaster(GenreMaster genreMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenre_id", genreMaster.genre_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenere_name", genreMaster.genere_name));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Delete_spGenremaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }

        public async Task<List<GenreMaster>> GetAllGenremaster()
        {
            List<GenreMaster> genreMasters = new List<GenreMaster>();
            GenreMaster genreMaster = null;
            try
            {
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("GetAllGenreMaster", null).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    genreMaster = new GenreMaster
                    {
                        genre_id = Convert.ToInt32(mySqlDataReader["genre_id"]),
                        genere_name = Convert.ToString(mySqlDataReader["genere_name"]),
                    };
                    genreMasters.Add(genreMaster);
                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return genreMasters;
        }

        public async Task<GenreMaster> GetGenremaster(int genre_id)
        {
            GenreMaster genreMaster = null;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenre_id", genre_id));
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("GetbyId_spGenreMaster", mySqlParameters).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    genreMaster = new GenreMaster();
                    genreMaster.genre_id = Convert.ToInt32(mySqlDataReader["genre_id"]);
                    genreMaster.genere_name = Convert.ToString(mySqlDataReader["genere_name"]);

                }
                mySqlDataReader.Close();
                mySqlDataReader.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return genreMaster;
        }

        public async Task<int> ModifyGenremaster(GenreMaster genreMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenre_id", genreMaster.genre_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenere_name", genreMaster.genere_name));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Update_spGenremaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }

        public async Task<int> SaveGenremaster(GenreMaster genreMaster)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenre_id", genreMaster.genre_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("igenere_name", genreMaster.genere_name));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Insert_spgenremaster", mySqlParameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inserted;
        }
    }
}
