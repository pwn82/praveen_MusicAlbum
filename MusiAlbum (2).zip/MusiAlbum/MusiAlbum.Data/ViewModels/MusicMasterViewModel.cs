﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.ViewModels
{
    public class MusicMasterViewModel
    {
        public int album_id { get; set; }
        public string album_name { get; set; }
        public int year { get; set; }
        public int title_id { get; set; }
        public string title_name { get; set; }
        public int artist_id { get; set; }
        public string artist_name { get; set; }
        public string profession { get; set; }
        public int genre_id { get; set; }
        public string genere_name { get; set; }
    }
}
